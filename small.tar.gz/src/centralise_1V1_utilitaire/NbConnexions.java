package centralise_1V1_utilitaire;

public class NbConnexions {
	private int nb_connexions = 0;

	public int getNb_connexions() {
		return nb_connexions;
	}

	public void setNb_connexions(int nb_connexions) {
		this.nb_connexions = nb_connexions;
	}
	
	
}
