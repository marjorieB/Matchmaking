package centralise_1V1_utilitaire;

public interface ServeurItf {
	public void matchmaking(JoueurItf j);
}
